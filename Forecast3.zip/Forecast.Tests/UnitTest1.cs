﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Forecast.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetWeatherWithNoCity()
        {

        }

        [TestMethod]
        public void GetWeatherWithInvalidCity()
        {

        }

        [TestMethod]
        public void GetWeatherWithValidCity()
        {

        }



        // Fetch web service call with pre-supplied city
        // Transform
    }
}
