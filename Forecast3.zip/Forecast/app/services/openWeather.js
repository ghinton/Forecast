﻿// OpenWeather API Service call
var serviceName = "weatherService";
var forecast = angular.module("forecast")
.factory(serviceName, ["$http", function ($http) {
    // begin factory code
    function getWeatherByCity(cityName) {
        var url = "api/forecast/" + cityName;
        return $http({
            method: "GET",
            url: url,
            data: cityName
        });
    }
        // Return the methods we want to expose
    return { getWeatherByCity: getWeatherByCity };
}]);